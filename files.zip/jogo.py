# jogo
import pygame
import sys
from personagens import Jardineiro, planta_longa, planta_corpo_a_corpo
from plataforma import Plataforma

LARGURA = 900
ALTURA = 600

BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
CINZA = (180, 180, 180)
VERDE_CLARO = (144, 238, 144)
VERDE_ESCURO = (0, 128, 0)
VERMELHO = (200, 50, 50)


class Botao:
    def __init__(self, x, y, largura, altura, texto, fonte, cor=VERDE_CLARO, cor_hover=VERDE_ESCURO):
        self.rect = pygame.Rect(x, y, largura, altura)
        self.texto = texto
        self.fonte = fonte
        self.cor = cor
        self.cor_hover = cor_hover

    def desenhar(self, tela, mouse_pos):
        cor_atual = self.cor_hover if self.rect.collidepoint(mouse_pos) else self.cor
        pygame.draw.rect(tela, cor_atual, self.rect, border_radius=25)
        texto_surf = self.fonte.render(self.texto, True, BRANCO)
        texto_rect = texto_surf.get_rect(center=self.rect.center)
        tela.blit(texto_surf, texto_rect)

    def clique(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)


class Jogo:
    def __init__(self):
        pygame.init()
        self.largura = LARGURA
        self.altura = ALTURA

        self.tela = pygame.display.set_mode((self.largura, self.altura))
        pygame.display.set_caption("Garden Alive - Jardineiro")

        self.rodando = True
        self.clock = pygame.time.Clock()

        self.fonte_titulo = pygame.font.SysFont("arial", 70, bold=True)
        self.fonte_botao = pygame.font.SysFont("arial", 36, bold=True)
        self.fonte_hud = pygame.font.SysFont("arial", 24, bold=True)
        self.fonte_info = pygame.font.SysFont("arial", 26)

        self.estado = "menu"  # "menu", "jogo" ou "game_over"

        self.botao_jogar = Botao(self.largura // 2 - 150, 240, 300, 65, "Jogar", self.fonte_botao)
        self.botao_creditos = Botao(self.largura // 2 - 150, 320, 300, 65, "Creditos", self.fonte_botao)
        self.botao_sair = Botao(self.largura // 2 - 150, 400, 300, 65, "Sair", self.fonte_botao)

        self.botao_continuar = Botao(self.largura // 2 - 220, 350, 200, 60, "Continuar", self.fonte_botao)
        self.botao_menu_go = Botao(self.largura // 2 + 20, 350, 200, 60, "Menu", self.fonte_botao)

        self._nova_fase()

    def _nova_fase(self):
        self.jardineiro = Jardineiro(150, 200)

        self.plataformas = [
            Plataforma(0, 550, 900, 50),
            Plataforma(200, 420, 180, 25),
            Plataforma(500, 320, 180, 25),
            Plataforma(150, 220, 120, 25),
            Plataforma(650, 450, 150, 25),
        ]

        # tipo_morte define se a planta so morre no corte ("tesoura") ou na rega ("regador")
        self.plantas = [
            planta_corpo_a_corpo(320, 485, tipo_morte="tesoura"),
            planta_longa(600, 485, tipo_morte="regador"),
            planta_corpo_a_corpo(750, 385, tipo_morte="regador"),
        ]

    def verificar_eventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                self.rodando = False

            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE:
                    self.rodando = False

                if evento.key == pygame.K_t:
                    if self.estado == "jogo":
                        self.estado = "menu"
                    elif self.estado == "menu":
                        self.estado = "jogo"

                if evento.key == pygame.K_r and self.estado == "jogo":
                    self.jardineiro.trocar_modo()

            if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                mouse_pos = pygame.mouse.get_pos()

                if self.estado == "menu":
                    if self.botao_jogar.clique(mouse_pos):
                        self.estado = "jogo"
                    elif self.botao_creditos.clique(mouse_pos):
                        print(">>> Creditos: feito por voce :)")
                    elif self.botao_sair.clique(mouse_pos):
                        self.rodando = False

                elif self.estado == "jogo":
                    if self.jardineiro.modo == "tesoura":
                        self.jardineiro.atacar_tesoura(self.plantas)

                elif self.estado == "game_over":
                    if self.botao_continuar.clique(mouse_pos):
                        self._nova_fase()
                        self.estado = "jogo"
                    elif self.botao_menu_go.clique(mouse_pos):
                        self._nova_fase()
                        self.estado = "menu"

    def atualizar(self):
        if self.estado != "jogo":
            return

        teclas = pygame.key.get_pressed()
        self.jardineiro.update(teclas, self.largura, self.altura, self.plataformas)

        # regar e continuo: enquanto o botao esquerdo estiver pressionado no modo regador
        if self.jardineiro.modo == "regador" and pygame.mouse.get_pressed()[0]:
            self.jardineiro.regar(self.plantas)

        jx = self.jardineiro.pos_x + self.jardineiro.largura / 2
        jy = self.jardineiro.pos_y + self.jardineiro.altura / 2

        for planta in self.plantas:
            if planta.vida <= 0:
                continue
            planta.update(self.jardineiro, self.plataformas)

            for proj in getattr(planta, "projetils", [])[:]:
                if abs(proj.x - jx) < 20 and abs(proj.y - jy) < 30:
                    self.jardineiro.tomar_dano(proj.dano)
                    planta.projetils.remove(proj)

        if self.jardineiro.vida <= 0:
            self.estado = "game_over"

    def desenhar_hud(self):
        vida_texto = self.fonte_hud.render(f"Vida: {self.jardineiro.vida}/{self.jardineiro.vida_maxima}", True, BRANCO)
        self.tela.blit(vida_texto, (20, 15))

        modo_texto = self.fonte_hud.render(f"Modo: {self.jardineiro.modo.upper()} (R)", True, BRANCO)
        self.tela.blit(modo_texto, (20, 45))

        pontos_texto = self.fonte_hud.render(f"Pontos: {self.jardineiro.pontuacao}", True, BRANCO)
        self.tela.blit(pontos_texto, (20, 75))

    def desenhar(self):
        mouse_pos = pygame.mouse.get_pos()

        if self.estado == "menu":
            self.tela.fill(PRETO)
            titulo = self.fonte_titulo.render("GARDEN ALIVE", True, BRANCO)
            self.tela.blit(titulo, titulo.get_rect(center=(self.largura // 2, 130)))

            subtitulo = self.fonte_info.render("Menu Principal", True, CINZA)
            self.tela.blit(subtitulo, subtitulo.get_rect(center=(self.largura // 2, 185)))

            self.botao_jogar.desenhar(self.tela, mouse_pos)
            self.botao_creditos.desenhar(self.tela, mouse_pos)
            self.botao_sair.desenhar(self.tela, mouse_pos)

            instrucao = self.fonte_info.render("Clique nos botoes com o mouse", True, CINZA)
            self.tela.blit(instrucao, instrucao.get_rect(center=(self.largura // 2, 520)))

        elif self.estado == "jogo":
            self.tela.fill((25, 25, 45))
            for plataforma in self.plataformas:
                plataforma.desenhar(self.tela)
            for planta in self.plantas:
                planta.desenhar(self.tela)
            self.jardineiro.desenhar(self.tela)
            self.desenhar_hud()

        elif self.estado == "game_over":
            self.tela.fill((40, 10, 10))
            texto = self.fonte_titulo.render("GAME OVER", True, VERMELHO)
            self.tela.blit(texto, texto.get_rect(center=(self.largura // 2, 200)))

            pontos_texto = self.fonte_info.render(f"Pontos: {self.jardineiro.pontuacao}", True, BRANCO)
            self.tela.blit(pontos_texto, pontos_texto.get_rect(center=(self.largura // 2, 270)))

            self.botao_continuar.desenhar(self.tela, mouse_pos)
            self.botao_menu_go.desenhar(self.tela, mouse_pos)

        pygame.display.flip()

    def iniciar(self):
        while self.rodando:
            self.verificar_eventos()
            self.atualizar()
            self.desenhar()
            self.clock.tick(60)

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    jogo = Jogo()
    jogo.iniciar()
