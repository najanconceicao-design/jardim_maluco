# personagens
import pygame
from plataforma import Plataforma


class Jardineiro:
    def __init__(self, x, y):
        self.pos_x = x
        self.pos_y = y
        self.vel_x = 0
        self.vel_y = 0
        self.vel = 6
        self.direcao_x = 1
        self.direcao_y = 0

        self.jump_force = -15
        self.gravidade = 0.8
        self.chao = False

        self.largura = 45
        self.altura = 75

        # Modo de ataque: "tesoura" (corte instantaneo) ou "regador" (rega continua)
        self.modo = "tesoura"
        self.alcance_tesoura = 70
        self.raio_regador = 90

        self.cooldown_ataque = 0
        self.cooldown_ataque_max = 20

        # Vida e status
        self.vida_maxima = 3
        self.vida = self.vida_maxima
        self.invulneravel = False
        self.tempo_invulneravel = 0
        self.pontuacao = 0

    def trocar_modo(self):
        self.modo = "regador" if self.modo == "tesoura" else "tesoura"

    def mover(self, direcao):
        if direcao == 'a':
            self.pos_x -= 1
        elif direcao == 'd':
            self.pos_x += 1
        elif direcao == 'w':
            self.pos_y -= 1

    def update(self, keys, screen_width, screen_height, plataformas=None):
        if plataformas is None:
            plataformas = []

        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.vel_x = -self.vel
            self.direcao_x = -1
        elif keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.vel_x = self.vel
            self.direcao_x = 1
        else:
            self.vel_x = 0

        if (keys[pygame.K_w] or keys[pygame.K_SPACE] or keys[pygame.K_UP]) and self.chao:
            self.vel_y = self.jump_force
            self.chao = False

        self.vel_y += self.gravidade
        self.pos_x += self.vel_x
        self.pos_y += self.vel_y

        if self.invulneravel:
            self.tempo_invulneravel -= 1
            if self.tempo_invulneravel <= 0:
                self.invulneravel = False

        if self.cooldown_ataque > 0:
            self.cooldown_ataque -= 1

        self.chao = False
        for plat in plataformas:
            if self.vel_y >= 0:
                bottom = self.pos_y + self.altura
                prev_bottom = bottom - self.vel_y

                if (self.pos_x + self.largura > plat.x and
                        self.pos_x < plat.x + plat.largura and
                        bottom >= plat.y and
                        prev_bottom <= plat.y):
                    self.pos_y = plat.y - self.altura
                    self.vel_y = 0
                    self.chao = True
                    break

        if self.pos_x < 0:
            self.pos_x = 0
        if self.pos_x + self.largura > screen_width:
            self.pos_x = screen_width - self.largura

        if self.pos_y > screen_height + 100:
            self.tomar_dano(self.vida_maxima)

    def centro(self):
        return (self.pos_x + self.largura / 2, self.pos_y + self.altura / 2)

    def atacar_tesoura(self, plantas):
        """Corte instantaneo com a tesoura gigante (modo 'tesoura')."""
        if self.modo != "tesoura" or self.cooldown_ataque > 0:
            return
        self.cooldown_ataque = self.cooldown_ataque_max
        cx, cy = self.centro()
        for planta in plantas:
            if planta.vida <= 0 or planta.tipo_morte != "tesoura":
                continue
            px = planta.x + planta.largura / 2
            py = planta.y + planta.altura / 2
            distancia = ((cx - px) ** 2 + (cy - py) ** 2) ** 0.5
            if distancia <= self.alcance_tesoura:
                planta.tomar_dano(35)
                if planta.vida <= 0:
                    self.pontuacao += 5

    def regar(self, plantas):
        """Chamado a cada frame enquanto o mouse e segurado no modo 'regador'."""
        if self.modo != "regador":
            return
        cx, cy = self.centro()
        for planta in plantas:
            if planta.vida <= 0 or planta.tipo_morte != "regador":
                continue
            px = planta.x + planta.largura / 2
            py = planta.y + planta.altura / 2
            distancia = ((cx - px) ** 2 + (cy - py) ** 2) ** 0.5
            if distancia <= self.raio_regador:
                estava_viva = planta.vida > 0
                planta.regar()
                if estava_viva and planta.vida <= 0:
                    self.pontuacao += 5

    def tomar_dano(self, quantidade):
        if not self.invulneravel:
            self.vida = max(0, self.vida - quantidade)
            self.invulneravel = True
            self.tempo_invulneravel = 45
            if self.vida <= 0:
                self.morrer()

    def morrer(self):
        print("💀 Hoje as plantas estao bem alimentadas...")

    def desenhar(self, tela):
        cor_corpo = (255, 255, 255) if not self.invulneravel else (255, 120, 120)
        pygame.draw.rect(tela, cor_corpo, (self.pos_x, self.pos_y, self.largura, self.altura), border_radius=8)

        cor_modo = (220, 220, 40) if self.modo == "tesoura" else (40, 160, 255)
        pygame.draw.circle(tela, cor_modo, (int(self.pos_x + self.largura / 2), int(self.pos_y - 12)), 8)


class Projetil:
    def __init__(self, x, y, direcao):
        self.x = x
        self.y = y
        self.velocidade = 8
        self.direcao = direcao
        self.largura = 15
        self.altura = 15
        self.dano = 1
        self.cor = (0, 255, 100)

    def update(self):
        self.x += self.velocidade * self.direcao

    def desenhar(self, tela):
        pygame.draw.circle(tela, self.cor, (int(self.x), int(self.y)), self.largura // 2)


class _PlantaBase:
    """Atributos e comportamento comuns a todas as plantas."""

    def __init__(self, x, y, tipo_morte):
        self.x = x
        self.y = y
        self.tipo_morte = tipo_morte  # "tesoura" ou "regador"
        self.sendo_regada = False
        self.barra_rega = 0
        self.barra_rega_max = 100
        self.decaimento_rega = 0.4  # a barra esvazia aos poucos se parar de regar

    def regar(self):
        """Chamado pelo jardineiro enquanto esta regando esta planta."""
        self.sendo_regada = True
        self.barra_rega += 2
        if self.barra_rega >= self.barra_rega_max:
            self.morrer()

    def _atualizar_barra_rega(self):
        if self.sendo_regada:
            self.sendo_regada = False  # reset por frame; regar() reativa se ainda estiver no alcance
        elif self.barra_rega > 0:
            self.barra_rega = max(0, self.barra_rega - self.decaimento_rega)

    def desenhar_icone(self, tela):
        icone_x = int(self.x + self.largura / 2)
        icone_y = int(self.y - 18)
        cor = (220, 220, 40) if self.tipo_morte == "tesoura" else (40, 160, 255)
        pygame.draw.circle(tela, cor, (icone_x, icone_y), 8)

        if self.barra_rega > 0:
            largura_barra = 40
            base_x = self.x + self.largura / 2 - largura_barra / 2
            pygame.draw.rect(tela, (60, 60, 60), (base_x, self.y - 34, largura_barra, 6))
            preenchido = largura_barra * (self.barra_rega / self.barra_rega_max)
            pygame.draw.rect(tela, (40, 160, 255), (base_x, self.y - 34, preenchido, 6))


class planta_longa(_PlantaBase):
    def __init__(self, x, y, tipo_morte="regador"):
        super().__init__(x, y, tipo_morte)
        self.largura = 60
        self.altura = 65
        self.vida = 60
        self.vida_max = 60
        self.alcance_ataque = 275
        self.cooldown_ataque = 0
        self.cooldown_max = 105
        self.projetils = []
        self.estado = "idle"
        self.cor = (180, 60, 160)

    def update(self, jardineiro, plataformas=None):
        self._atualizar_barra_rega()

        if self.cooldown_ataque > 0:
            self.cooldown_ataque -= 1

        # nao ataca enquanto esta sendo regada
        if self.barra_rega == 0:
            distancia = abs(jardineiro.pos_x - self.x)
            if distancia < self.alcance_ataque and self.cooldown_ataque == 0:
                self.atacar(jardineiro.pos_x > self.x)
                self.cooldown_ataque = self.cooldown_max

        for proj in self.projetils[:]:
            proj.update()
            if proj.x < -50 or proj.x > 1200:
                self.projetils.remove(proj)

    def atacar(self, para_direita):
        self.estado = "atacando"
        boca_x = self.x + 50 if para_direita else self.x + 10
        boca_y = self.y + 30
        direcao = 1 if para_direita else -1
        self.projetils.append(Projetil(boca_x, boca_y, direcao))

    def tomar_dano(self, quantidade):
        self.vida -= quantidade
        if self.vida <= 0:
            self.morrer()

    def morrer(self):
        self.vida = 0
        print("🌿 Erva daninha podada!")

    def desenhar(self, tela):
        if self.vida <= 0:
            return
        pygame.draw.rect(tela, self.cor, (self.x, self.y, self.largura, self.altura), border_radius=6)
        for proj in self.projetils:
            proj.desenhar(tela)
        self.desenhar_icone(tela)


class planta_corpo_a_corpo(_PlantaBase):
    def __init__(self, x, y, tipo_morte="tesoura"):
        super().__init__(x, y, tipo_morte)
        self.largura = 60
        self.altura = 65
        self.vida = 90
        self.vida_max = 90
        self.alcance_ataque = 85
        self.cooldown_ataque = 0
        self.cooldown_max = 55
        self.estado = "idle"
        self.dano = 1
        self.cor = (200, 90, 40)

    def update(self, jardineiro, plataformas=None):
        self._atualizar_barra_rega()

        if self.cooldown_ataque > 0:
            self.cooldown_ataque -= 1

        if self.barra_rega == 0:
            distancia = abs(jardineiro.pos_x - self.x)
            if distancia < self.alcance_ataque and self.cooldown_ataque == 0:
                self.atacar(jardineiro)
                self.cooldown_ataque = self.cooldown_max

    def atacar(self, jardineiro):
        self.estado = "atacando"
        if hasattr(jardineiro, 'tomar_dano'):
            jardineiro.tomar_dano(self.dano)

    def tomar_dano(self, quantidade):
        self.vida -= quantidade
        if self.vida <= 0:
            self.morrer()

    def morrer(self):
        self.vida = 0
        print("🌿 Erva daninha podada!")

    def desenhar(self, tela):
        if self.vida <= 0:
            return
        pygame.draw.rect(tela, self.cor, (self.x, self.y, self.largura, self.altura), border_radius=6)
        self.desenhar_icone(tela)
